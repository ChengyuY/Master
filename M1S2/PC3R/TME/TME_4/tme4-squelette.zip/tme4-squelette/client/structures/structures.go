package structures

type Personne struct {
	Nom    string
	Prenom string
	Age    int
	Sexe   string
}
