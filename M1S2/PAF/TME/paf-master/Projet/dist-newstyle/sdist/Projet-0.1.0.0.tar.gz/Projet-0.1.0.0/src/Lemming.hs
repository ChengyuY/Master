module Lemming where

import Coord

data Direction = Gauche | Droite
    deriving (Eq,Show)

data Lemming = Marcheur Direction Coord
             | Tombeur Direction Int Coord
             | Mort Coord
        deriving Eq 


instance Show Lemming where
    show (Mort _) = "+"
    show (Marcheur Gauche _) = "<"
    show (Marcheur Droite _) = ">"
    show (Tombeur _ _ _) = "v"

instance Placable Lemming where
    coordP = coordLemming
    bougeP = bougeLemming
    deplaceP = deplaceLemming

coordLemming :: Lemming -> Coord
coordLemming (Marcheur _ c) = c
coordLemming (Mort c) = c 
coordLemming (Tombeur _ _ c) = c 

tueLemming :: Lemming -> Lemming
tueLemming l = Mort (coordLemming l)

prop_tueLemming_post :: Lemming -> Bool
prop_tueLemming_post l = case tueLemming l of 
                            Mort c -> c == coordLemming l
                            _ -> False 

bougeLemming :: Deplacement -> Lemming -> Lemming
bougeLemming dep (Marcheur dir c ) = Marcheur dir (bougeCoord dep c)
bougeLemming dep (Mort c) = Mort (bougeCoord dep c)
bougeLemming dep (Tombeur dir n c ) = Tombeur dir n (bougeCoord dep c)

prop_bougeLemmingDHDBG :: Lemming -> Bool
prop_bougeLemmingDHDBG l = bougeLemming D l == (bougeLemming G . bougeLemming DB . bougeLemming DH) l

deplaceLemming :: Coord -> Lemming -> Lemming
deplaceLemming c (Mort _) = Mort c
deplaceLemming c (Marcheur d _) = Marcheur d c
deplaceLemming c (Tombeur d n _) = Tombeur d n c 

