module Etat where

import Lemming 
import Coord 

import Environnement

import Niveau

data Etat = Etat {
    enviE :: Envi,
    niveauE :: Niveau,
    lrestantsE :: Int,
    lvivantsE :: Int,
    lsauvesE :: Int
}

data Fin = Victoire Int | Defaite

hauteurMortelle :: Int
hauteurMortelle = 5

rassembleEnvNiv :: String -> String -> String
rassembleEnvNiv [] _ = [] 
rassembleEnvNiv _ [] = []
rassembleEnvNiv (x1:xs1) (x2:xs2) = if x1 == ' ' then x2:rassembleEnvNiv xs1 xs2 else x1:rassembleEnvNiv xs1 xs2 

showEtat :: Etat -> String
showEtat e = rassembleEnvNiv (show (enviE e)) (show (niveauE e))

instance Show Etat where
    show = showEtat

tourLemming n (Marcheur Gauche c) (Etat envi niv r m s) = case trouveSortie niv of
                                                            Nothing -> suite
                                                            Just cs -> if cs == c then Etat (enleveEnvi n envi) niv r (m-1) (s+1) else suite
                                                            where suite = 
                                                                    case (passable (gauche c) niv && passable (haut (gauche c)) niv, passable (haut (gauche c)) niv && passable (haut (haut (gauche c))) niv, dur (bas c) niv) of
                                                                        (_,_,False) -> Etat (appliqueIdEnv n (const (Lem n (Tombeur Gauche 0 c))) envi) niv r m s
                                                                        (True,_,_) -> Etat (deplaceDansEnvi n (gauche c) envi) niv r m s
                                                                        (_,True,_) -> Etat (deplaceDansEnvi n (haut (gauche c)) envi) niv r m s
                                                                        (_,_,_) -> Etat (appliqueIdEnv n (const (Lem n (Marcheur Droite c))) envi) niv r m s
tourLemming n (Marcheur Droite c) (Etat envi niv r m s) = case trouveSortie niv of
                                                            Nothing -> suite
                                                            Just cs -> if cs == c then Etat (enleveEnvi n envi) niv r (m-1) (s+1) else suite
                                                            where suite = 
                                                                    case (passable (droite c) niv && passable (haut (droite c)) niv, passable (haut (droite c)) niv && passable (haut (haut (droite c))) niv, dur (bas c) niv) of
                                                                        (_,_,False) -> Etat (appliqueIdEnv n (const (Lem n (Tombeur Droite 0 c))) envi) niv r m s
                                                                        (True,_,_) -> Etat (deplaceDansEnvi n (droite c) envi) niv r m s
                                                                        (_,True,_) -> Etat (deplaceDansEnvi n (haut (droite c)) envi) niv r m s
                                                                        (_,_,_) -> Etat (appliqueIdEnv n (const (Lem n (Marcheur Gauche c))) envi) niv r m s
tourLemming n (Tombeur dir k c) (Etat envi niv r m s) = case (dur (bas c) niv, k >= hauteurMortelle) of
                                                            (True,True) -> Etat (appliqueIdEnv n (const (Lem n (Mort c))) envi) niv r m s
                                                            (True,_) -> Etat (appliqueIdEnv n (const (Lem n (Marcheur dir c))) envi) niv r m s
                                                            (_,_) -> Etat (appliqueIdEnv n (const (Lem n (Tombeur dir (k+1) (bas c)))) (deplaceDansEnvi n (bas c) envi)) niv r m s


tourEntite :: Int -> Etat -> Etat
tourEntite n et = case trouveIdEnv n (enviE et) of
                    Nothing -> et
                    Just (Lem _ l) -> tourLemming n l et

popLem :: Etat -> Etat
popLem (Etat envi niv r v s) = case trouveEntree niv of
                                Nothing -> Etat envi niv r v s
                                Just c -> Etat nenvi niv (r-1) (v+1) s
                                            where nenvi = addEntite nlem envi
                                                  nlem = Lem (idFrais envi) (Tombeur Droite 0 c)


tourEtat :: Int -> Etat -> Either Fin Etat 
tourEtat t e = (verif . pop) $ foldr etape e (entitesEnvi2 (enviE e))
                 where etape enti acc = tourEntite (idEnt enti) acc
                       pop = if restants > 0 && t `mod` 5 == 0 then popLem else id 
                       restants = lrestantsE e
                       verif et = if lrestantsE et == 0 && lvivantsE et == 0
                                     then Left $ Victoire $ lsauvesE et
                                     else Right et                                                 
                                              