# PAF TME 8 : Générateurs monadiques avec QuickCheck

L'énoncé de ce TME se trouve dans le fichier
`src/PAF_TME8_GenMonad.hs` qu'il faut compléter directement
dans les sources.

Bon travail !

----
Copyright (C) 2021 - Frédéric Peschanski



